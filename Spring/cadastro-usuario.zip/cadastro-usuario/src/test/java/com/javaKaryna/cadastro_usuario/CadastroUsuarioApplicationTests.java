package com.javaKaryna.cadastro_usuario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadastroUsuarioApplicationTests {

	@Test
	void contextLoads() {
	}

}
